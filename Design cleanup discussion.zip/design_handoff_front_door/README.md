# Handoff: Front Door (Piston List) Page

## Overview
Cleaned-up design for PistonCore's Piston List page ("front door") — the home screen listing all automations, with a folder sidebar, search, and per-row controls (enable/pause, delete).

## About the Design Files
The bundled file, `front_door.html`, is a **design reference built in plain HTML/CSS/vanilla JS** — it intentionally mirrors your existing Jinja template (`templates/front_door.html`) markup, class names, and element ids 1:1, so it's meant to be diffed directly against that template rather than recreated from scratch. Port the CSS into your real stylesheet and the JS behavior into `front_door.js`, keeping the Jinja `{% for %}` loops and template variables from your existing template.

## Fidelity
High-fidelity. Colors, spacing, and type values below are final and pulled from the PistonCore Design System tokens.

## Screens / Views

### Front Door — Piston List
**Purpose:** browse, search, filter by folder, enable/pause, and delete pistons.

**Layout:**
- `#global-header`: 52px fixed header, flex row, `padding: 0 16px`, `gap: 8px`, bottom border.
- `#page-container`: `max-width: 1100px`, centered, `padding: 24px 20px 60px`.
- `.list-header`: flex row, space-between, `margin-bottom: 20px`.
- `.fd-layout`: CSS grid, `grid-template-columns: 200px 1fr`, `gap: 20px`.
- `.fd-sidebar`: now a card panel — `background: var(--color-surface)`, `border: 1px solid var(--color-border)`, `border-radius: 8px`, `padding: 8px`, sticky at `top: 24px`. (This was the change from the previous version — previously it had no background/border and looked like it was floating in empty space.)
- `.fd-list`: flex column, `gap: 12px`; contains folder header, search input, row list.
- `.piston-row`: flex row, `gap: 14px`, `padding: 12px 14px`, surface card with border, hover border turns accent blue.

**Components:**
- **Folder buttons** (`.folder-btn`): left-aligned, `padding: 8px 12px`, `border-radius: 4px` (changed from asymmetric radius since the sidebar is now boxed), 3px left border accent when `.active`, count badge pill on the right.
- **Search input** (`#fd-search`): full width, surface background, border, `padding: 9px 12px`.
- **Piston row**: enabled dot (green/dim) → name + description + "Modified …" meta → compile-status pill (`deployed`/`compile error`/`needs PyScript`/`paused`/`not compiled`, color-coded) → Pause/Enable ghost button → Delete ghost button.
- **Delete button**: uses the same `.btn-ghost` base as other row buttons (not an inline style override) — red text (`var(--color-error)`), and on hover gets a red-tinted background (`rgba(244,67,54,.12)`) and red border, so it matches the other ghost buttons' interaction pattern instead of looking like a one-off.

## Interactions & Behavior
- Typing in `#fd-search` filters rows by a precomputed lowercase `data-search` string (name + description).
- Clicking a folder button sets `.active`, filters rows by `data-category`, updates the folder title label.
- Clicking Pause/Enable toggles `data-active`, flips the dot color and button label.
- Clicking Delete removes the row from the DOM.
- `#fd-empty` "No pistons match." message shows when a filter yields zero visible rows.
- Transitions: `background 0.15s`, `border-color 0.15s`, `color 0.15s` only — no bounce/spring/entrance animation, per design system.

## State Management
- `activeFolder` (client-side string, currently vanilla JS `let`) — drives row visibility.
- Per-row `data-active` attribute — mirrors the piston's enabled/disabled state; wire to your real enable/disable API call.
- Search query — client-side substring filter; fine to keep client-side if piston counts stay in the hundreds, otherwise move to a server query.

## Design Tokens
```
--color-bg: #1a1a2e
--color-surface: #16213e
--color-surface-2: #0f3460
--color-border: #2a2a4a
--color-accent: #4a9eff
--color-accent-hover: #6eb5ff
--color-success: #4caf50
--color-warning: #ff9800
--color-error: #f44336
--color-text: #e8e8f0
--color-text-muted: #9999bb
--color-text-dim: #666688
--font-ui: system-ui, -apple-system, sans-serif
--font-mono: 'Courier New', Courier, monospace
--radius: 4px
--radius-lg: 8px
--shadow: 0 2px 8px rgba(0,0,0,0.4)
base font-size: 14px
```

## Assets
No icons/images in this screen besides the header's inline SVGs (help, settings, device-tester, theme-toggle) — already present in your `templates/base.html`, unchanged.

## Files
- `front_door.html` — the full reference page (structure + CSS + JS), diff against `templates/front_door.html` / `static/pistoncore/style.css` / `static/pistoncore/front_door.js`.
