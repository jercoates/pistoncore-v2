# Handoff: PistonCore Web App UI Kit

## Overview
Click-through prototype of PistonCore's editor web app: three core screens (Piston List, Status/Hub, Piston Editor) for a self-hosted Home Assistant automation builder.

## About the Design Files
The files in this bundle are **design references built in HTML/React (inline Babel, no build step)** — prototypes showing intended look and behavior, not production code to copy directly. The task is to **recreate these designs in the target codebase's existing environment** (React app scaffold already exists at the project root — see `App.jsx`, `main.jsx`, `pages/`, `components/`) using its established patterns (React Router, TanStack Query, axios) rather than the mock inline-style/local-state approach used here.

## Fidelity
**High-fidelity.** Colors, typography, spacing, and copy are final per the design system. Interactions (navigation between screens, collapsible sections, toggles) are demonstrated but wired to mock/local state only — no real API calls.

## Screens / Views

### 1. Piston List Page (`PistonList`)
- **Purpose:** Browse/search pistons (automations) grouped by folder, jump into Status or Editor.
- **Layout:** max-width 1100px. Header row (title + search input) → flex layout: 200px folder sidebar + flexible row list.
- **Folder sidebar:** buttons, `#16213e` bg, `1px solid #2a2a4a` border, 4px radius, active state = `#4a9eff` text/border. Each shows a count badge (`#2a2a4a` bg, pill radius).
- **Piston row:** `#16213e` bg, 1px `#2a2a4a` border, 4px radius, 10px vertical padding. Left: enabled dot (`●` green `#4caf50` / `○` `#666688`). Middle: name (15px/500), description (13px muted `#9999bb`, truncated), meta line ("Last ran: X" or "Never deployed", 12px `#666688`). Right: pass/fail badge (green/red tint pill) + row actions (Pause/Enable, Edit buttons). Disabled rows at 0.55 opacity. Whole row clickable → Status page.

### 2. Status Page (`StatusPage`)
- **Purpose:** Hub for one piston — quick facts, validation state, run log, actions.
- **Layout:** max-width 820px. Breadcrumb → title row (name + active/paused pill) → folder row + pause button → optional validation warning banner (amber tint) → action button row (Edit, Test, Snapshot, Backup, Duplicate, Delete + Trace/Notify toggles) → Quick Facts card (2-col grid) → Log card (monospace lines, color-coded, log-level selector).
- **Cards:** `#16213e` bg, `#2a2a4a` border, 4px radius, 12–16px padding, uppercase 11px section labels in `#666688`.

### 3. Piston Editor Page (`EditorPage`)
- **Purpose:** Structured document editor for a piston's fields, triggers, conditions, and actions.
- **Layout:** max-width 860px. Toolbar (back link + Simple/Advanced mode toggle) → header card (Name/Description inputs, Folder/Mode/Status selects) → collapsible sections (Piston Variables [advanced only], Triggers, Conditions, Actions) → sticky-style footer (Save/Test/Snapshot/Backup + log level selector).
- **Collapsible section:** header row (▼/▶ + uppercase title + "+ Add" ghost action) toggles body visibility. Body renders content as a pseudo-document: lowercase keywords (`with`, `do`, `end with;`, `wait`) rendered in monospace accent-blue; "+ add a new statement/trigger/condition" ghost rows (dim text, brightens to accent blue on hover) as inline add affordances.

## Interactions & Behavior
- Client-side page switching (`list` / `status` / `editor` / `editor-new`) persisted to `localStorage` (`pc_page`, `pc_piston`) — in production this should be real routing (React Router, already in the codebase) with real piston IDs in the URL.
- Section collapse/expand is local component state (`open` boolean).
- Save button on Editor shows a transient "✓ Saved" state (800ms) then navigates to Status — placeholder for a real save mutation.
- Hover states: folder/nav items and ghost "+ add" rows transition `color`/`border-color` over 0.15s. No entrance animations, no bounce/spring easing anywhere in this system.
- All data (`MOCK_PISTONS`, log lines, quick facts) is static/mock — replace with real API-backed data.

## State Management
- `page`: current screen (`list` | `status` | `editor` | `editor-new`)
- `selectedPiston`: the piston object currently in view
- Per-screen local state: `search`/`activeFolder` (List), `trace`/`notify` toggles (Status), `name`/`desc`/`mode`/`advanced`/`saved` (Editor)
- Production state should move to the existing `@tanstack/react-query` setup (`utils/api.js`, `pages/*Page.jsx` at the project root already stub this out) instead of local component state + localStorage.

## Design Tokens
See `colors_and_type.css` (also bundled here) for the full token set. Key values:
- Background `#1a1a2e`, Surface `#16213e`, Surface 2 `#0f3460`, Border `#2a2a4a`
- Accent `#4a9eff` (hover `#6eb5ff`), Success `#4caf50`, Warning `#ff9800`, Error `#f44336`
- Text `#e8e8f0`, Text muted `#9999bb`, Text dim `#666688`
- UI font: `system-ui, -apple-system, sans-serif` (no web font). Mono: `'Courier New', Courier, monospace`. Base size 14px.
- Border radius: 4px (default), 8px (large). Spacing grid: 4px base (6/8/12/14/16/20/24).
- Shadow (sparingly, modals only): `0 2px 8px rgba(0,0,0,0.4)`.
- Nav active-state pattern: 3px left-border accent + `rgba(74,158,255,0.08)` tint background.
- No icon font is wired in; emoji glyphs here are placeholders — see the design system's README.md for the recommended Lucide icon substitution.

## Assets
No images/illustrations — this product uses no imagery, per brand guidelines (pure UI, dark theme only, no gradients/textures).

## Files
- `index.html` — full click-through prototype (React + Babel standalone, no build step). Contains `AppShell`, `PistonList`, `StatusPage`, `EditorPage` inline.
- `colors_and_type.css` — design token reference (CSS custom properties).
